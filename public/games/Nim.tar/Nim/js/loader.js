(function() {
  JSG.Util.loadGameData(
      "Nim", [
        "game.js",
        "board.js",
        "board_ui.js",
        "perfect_ai.js"
      ], [
        "board.css"
      ], [
        "no_stone.png",
        "selected_stone.png",
        "unselected_stone.png"
      ]);
}());
